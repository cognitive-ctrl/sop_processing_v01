import os
import yaml
import openpyxl
import openai
import json
from io import BytesIO

CONFIG_DIR = os.path.join(os.path.dirname(__file__), '../../../input/config')

# Load prompt config strictly as-is
with open(os.path.join(CONFIG_DIR, 'prompt.yaml'), encoding='utf-8') as f:
    PROMPT_CONFIG = yaml.safe_load(f)

# Optionally load other configs as needed
with open(os.path.join(CONFIG_DIR, 'constants.yaml'), encoding='utf-8') as f:
    CONSTANTS = yaml.safe_load(f)
with open(os.path.join(CONFIG_DIR, 'params.yml'), encoding='utf-8') as f:
    PARAMS = yaml.safe_load(f)

# Add more config loads as required

def generate_prompt(row, prompt_config):
    """
    Generate a prompt for a given row using the strict prompt config.
    """
    # Example: Use a template from prompt_config and fill with row data
    # This logic should be adapted to your actual prompt config structure
    template = prompt_config.get('template')
    if not template:
        raise ValueError('Prompt template missing in config')
    return template.format(**row)



def process_excel_and_generate_json(excel_bytes):
    """
    Process the uploaded Excel file using openpyxl, generate prompts, call OpenAI, and return JSON results.
    """
    wb = openpyxl.load_workbook(BytesIO(excel_bytes), data_only=True)
    ws = wb.active
    headers = [cell.value for cell in next(ws.iter_rows(min_row=1, max_row=1))]
    results = []


    # Set OpenAI API key and endpoint from environment variable for security
    openai.api_key = os.environ.get("AZURE_OPENAI_API_KEY")
    openai.api_base = "https://oai0-cica-poc-resource.openai.azure.com/"
    if not openai.api_key:
        raise RuntimeError("AZURE_OPENAI_API_KEY environment variable is not set.")

    for row in ws.iter_rows(min_row=2, values_only=True):
        row_dict = dict(zip(headers, row))
        prompt = generate_prompt(row_dict, PROMPT_CONFIG)
        # Call OpenAI GPT-4.1
        response = openai.ChatCompletion.create(
            model="gpt-4.1",
            messages=[{"role": "user", "content": prompt}],
            temperature=PARAMS.get('temperature', 0.0),
            max_tokens=PARAMS.get('max_tokens', 1024)
        )
        answer = response['choices'][0]['message']['content']
        results.append({"input": row_dict, "prompt": prompt, "output": answer})
    return results


def save_json(results, output_path):
    with open(output_path, 'w', encoding='utf-8') as f:
        json.dump(results, f, ensure_ascii=False, indent=2)
