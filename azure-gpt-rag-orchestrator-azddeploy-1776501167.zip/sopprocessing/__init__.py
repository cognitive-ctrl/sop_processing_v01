import azure.functions as func
import logging
import json
from .sop_processing import process_excel_and_generate_json

async def main(req: func.HttpRequest) -> func.HttpResponse:
    try:
        formdata = await req.form()
        if 'file' not in formdata:
            return func.HttpResponse("No file uploaded.", status_code=400)
        file = formdata['file']
        excel_bytes = await file.read()
        results = process_excel_and_generate_json(excel_bytes)
        response_json = func.HttpResponse(
            body=json.dumps(results, ensure_ascii=False, indent=2),
            mimetype="application/json",
            status_code=200
        )
        response_json.headers["Content-Disposition"] = "attachment; filename=output.json"
        return response_json
    except Exception as e:
        logging.exception("Error processing SOP Excel file")
        return func.HttpResponse(f"Error: {str(e)}", status_code=500)
