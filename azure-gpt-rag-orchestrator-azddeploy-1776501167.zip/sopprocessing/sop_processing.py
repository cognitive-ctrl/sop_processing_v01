
import os
import yaml
import openpyxl
import openai
import json
import logging
from io import BytesIO

CONFIG_DIR = os.path.join(os.path.dirname(__file__), '../input/config')

def load_yaml_config(filename):
    path = os.path.join(CONFIG_DIR, filename)
    try:
        with open(path, encoding='utf-8') as f:
            return yaml.safe_load(f)
    except Exception as e:
        logging.error(f"Failed to load config {filename}: {e}")
        raise

PROMPT_CONFIG = load_yaml_config('prompt.yaml')
CONSTANTS = load_yaml_config('constants.yaml')
PARAMS = load_yaml_config('params.yml')

def generate_prompt(row, prompt_config):
    template = prompt_config.get('template')
    if not template:
        raise ValueError('Prompt template missing in config')
    try:
        return template.format(**row)
    except KeyError as e:
        logging.error(f"Missing key in row for prompt: {e}")
        raise

def process_excel_and_generate_json(excel_bytes):
    try:
        wb = openpyxl.load_workbook(BytesIO(excel_bytes), data_only=True)
        ws = wb.active
        headers = [cell.value for cell in next(ws.iter_rows(min_row=1, max_row=1))]
        results = []
        openai.api_key = os.environ.get("AZURE_OPENAI_API_KEY")
        openai.api_base = "https://oai0-cica-poc-resource.openai.azure.com/"
        if not openai.api_key:
            raise RuntimeError("AZURE_OPENAI_API_KEY environment variable is not set.")
        for row in ws.iter_rows(min_row=2, values_only=True):
            row_dict = dict(zip(headers, row))
            try:
                prompt = generate_prompt(row_dict, PROMPT_CONFIG)
            except Exception as e:
                logging.error(f"Prompt generation failed for row {row_dict}: {e}")
                continue
            try:
                response = openai.ChatCompletion.create(
                    model="gpt-4.1",
                    messages=[{"role": "user", "content": prompt}],
                    temperature=PARAMS.get('temperature', 0.0),
                    max_tokens=PARAMS.get('max_tokens', 1024)
                )
                answer = response['choices'][0]['message']['content']
            except Exception as e:
                logging.error(f"OpenAI API call failed for row {row_dict}: {e}")
                answer = f"Error: {e}"
            results.append({"input": row_dict, "prompt": prompt, "output": answer})
        return results
    except Exception as e:
        logging.error(f"Excel processing failed: {e}")
        raise

def save_json(results, output_path):
    try:
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(results, f, ensure_ascii=False, indent=2)
    except Exception as e:
        logging.error(f"Failed to save JSON: {e}")
        raise
